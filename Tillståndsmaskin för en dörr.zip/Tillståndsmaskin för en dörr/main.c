/********************************************************************************
* main.c: Implementering av en tillst�ndsmaskin f�r en d�rr, vars tillst�nd
*         indikeras via tre lysdioder LED1 - LED3 anslutna till pin 8 - 10
*         (PORTB0 - PORTB2) enligt nedan:
*
*         LED[1:3]   D�rrens tillst�nd
*           100           �ppen
*           010           St�ngd
*           001            L�st
*           111            Fel
*
*          Tre tryckknappar OPEN_BUTTON, CLOSE_BUTTON and LOCK_BUTTON anslutna 
*          till pin 11 - 13 (PORTB3 - PORTB5) anv�nds f�r att uppdatera d�rrens
*          tillst�nd. En resetknapp RESET_BUTTON ansluten till pin 2 (PORTD2)
*          anv�nds f�r att omedelbart �terst�lla d�rren till startl�get (�ppen).
********************************************************************************/
#include "header.h"

/********************************************************************************
* main: Initierar systemet vid start (konfigurerar I/O-portar samt aktiverar
*       avbrott p� tryckknapparnas pinnar). Programmet h�lls sedan ig�ng
*       kontinuerligt s� l�nge matningssp�nning tillf�rs. D�rrens tillst�nd
*       uppdateras via avbrottsrutiner.
********************************************************************************/
int main(void)
{
   setup();

   while (1)
   {

   }

   return 0;
}

