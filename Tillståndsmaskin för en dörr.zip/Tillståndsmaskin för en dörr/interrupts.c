/********************************************************************************
* interrupts.c: Inneh�ller avbrottsrutiner.
********************************************************************************/
#include "header.h"

/********************************************************************************
* ISR (PCINT0_vect): Avbrottsrutin f�r PCI-avbrott p� I/O-port B, som anropas 
*                    vid uppsl�ppning eller nedtryckning av tryckknappar
*                    anslutna till pin 11 - 13 (PORTB3 - PORTB4). Om n�gon av 
*                    dessa knappar trycks ned s� uppdateras d�rrens tillst�nd.
********************************************************************************/
ISR (PCINT0_vect)
{
   if (OPEN_BUTTON_PRESSED || CLOSE_BUTTON_PRESSED || LOCK_BUTTON_PRESSED)
   {
      fsm_update();
   }

   return;
}

/********************************************************************************
* ISR (INT0_vect): Avbrottsrutin, som anropas vid nedtryckning av reset-knappen
*                  ansluten till pin 2 (PORTD2). Vid reset s� �terst�lls d�rrens
*                  tillst�nd till startl�get (�ppet tillst�nd).
********************************************************************************/
ISR (INT0_vect)
{
   fsm_reset(); 
   return;
}