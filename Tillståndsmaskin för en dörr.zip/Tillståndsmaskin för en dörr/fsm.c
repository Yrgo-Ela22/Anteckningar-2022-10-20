/********************************************************************************
* fsm.c: Inneh�ller funktionalitet f�r implementering av tillst�ndsmaskinen.
********************************************************************************/
#include "header.h"

/* Statiska funktioner: */
static void fsm_set_output(void);

/* Statiska datamedlemmar: */
static enum door_state state = DOOR_STATE_OPEN; /* Lagrar d�rrens tillst�nd. */

/********************************************************************************
* fsm_reset: �terst�ller d�rren till startl�get, vilket �r �ppet tillst�nd.
*            Lysdioderna uppdateras d�refter (endast lysdiod 1 h�lls t�nd).
********************************************************************************/
void fsm_reset(void)
{
   state = DOOR_STATE_OPEN; 
   LED1_ON;
   LED2_OFF;
   LED3_OFF;
   return;
}

/********************************************************************************
* fsm_uppdate: Uppdaterar d�rrens tillst�nd utefter aktuellt tillst�nd samt
*              vilken tryckknapp som trycks ned. 
*
*              I feltillst�nd sker ingen uppdatering oavsett nedtryckning av
*              tryckknappar f�r att �ppna, st�nga eller l�sa d�rren. D�rren
*              m�ste �terst�llas innan uppdatering kan ske i vanlig ordning.
*
*              Om d�rrens tillst�nd f�rs�tts i ett icke definierat tillst�nd
*              s� �terst�lls d�rren direkt. Lysdioderna uppdateras utefter
*              aktuellt tillst�nd innan funktionen avslutas.
********************************************************************************/
void fsm_update(void)
{
   switch (state) 
   {
      case DOOR_STATE_OPEN: 
      {
         if (CLOSE_BUTTON_PRESSED)
         {
            state = DOOR_STATE_CLOSED;
         }
         else if (LOCK_BUTTON_PRESSED)
         {
            state = DOOR_STATE_ERROR;
         }

         break;
      }

      case DOOR_STATE_CLOSED: 
      {
         if (OPEN_BUTTON_PRESSED)
         {
            state = DOOR_STATE_OPEN;
         }
         else if (LOCK_BUTTON_PRESSED)
         {
            state = DOOR_STATE_LOCKED;
         }

         break;
      }

      case DOOR_STATE_LOCKED:
      {
         if (OPEN_BUTTON_PRESSED)
         {
            state = DOOR_STATE_ERROR;
         }
         else if (CLOSE_BUTTON_PRESSED)
         {
            state = DOOR_STATE_CLOSED;
         }
         break;
      }

      case DOOR_STATE_ERROR: 
      {
         break;
      }

      default: 
      {
         fsm_reset();
         break;
      }
   }

   fsm_set_output(); 
   return;
}

/********************************************************************************
* fsm_set_output: Uppdaterar lysdioderna utefter aktuellt tillst�nd enligt nedan:
*
*                 - Om d�rren �r �ppen t�nds lysdiod 1, �vriga h�lls sl�ckta.
*                 - Om d�rren �r st�ngd t�nds lysdiod 2, �vriga h�lls sl�ckta.
*                 - Om d�rren �r l�st t�nds lysdiod 3, �vriga h�lls sl�ckta.
*                 - Vid feltillst�nd t�nds samtliga lysdioder. 
*                 - Vid icke definierat tillst�nd �terst�lls d�rren till 
*                   startl�get, vilket �r �ppen.
********************************************************************************/
static void fsm_set_output(void)
{
   if (state == DOOR_STATE_OPEN) 
   {
      LED1_ON;
      LED2_OFF;
      LED3_OFF;
   }
   else if (state == DOOR_STATE_CLOSED)
   {
      LED1_OFF;
      LED2_ON;
      LED3_OFF;
   }
   else if (state == DOOR_STATE_LOCKED) 
   {
      LED1_OFF;
      LED2_OFF;
      LED3_ON;
   }
   else if (state == DOOR_STATE_ERROR) 
   {
      LEDS_ON;
   }
   else
   {
      fsm_reset();
   }

   return;
}


